package com.busrayalcin.a24tvcloneapp.utils

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}